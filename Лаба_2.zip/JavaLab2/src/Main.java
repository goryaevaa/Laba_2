public class Main {

public static void main(String[] args) {

Circle circle = new Circle(3);

System.out.println("Area = "+circle.getArea());

System.out.println("Perimeter = " +circle.getPerimeter());

circle.setRadius(10);

System.out.print(circle.toString());

}

}