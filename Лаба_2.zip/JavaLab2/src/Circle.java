public class Circle {
protected double radius;
public Circle()
{
radius=0;
}
public Circle(double radius)
{
this.radius=radius;
}
public Circle(double radius, String colour, boolean filled)
{
this.radius=radius;
}
public double getRadius()
{
return radius;
}
public void setRadius(double radius)
{
this.radius = radius;
}
public double getArea()
{
return 3.14*radius*radius;
}
public double getPerimeter()
{
return 2*3.14*radius;
}
public String toString() 
{
return "This object is circle. Its radius is "+ radius+"\nArea = "+getArea()+"\nPerimeter = " + getPerimeter();
} 
} 